module parteB {
}