package clases;

public abstract class Sistema {

}
