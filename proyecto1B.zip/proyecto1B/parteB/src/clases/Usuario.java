package clases;

public abstract class Usuario {
	Usuario(){
		
	}
	public void generarReporteNotas() {
		
	}
}
